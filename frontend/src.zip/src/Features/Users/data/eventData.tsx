import scholarship from '../../../asset/scholarship.jpg';
import ict from '../../../asset/ict.jpg';
import drone from '../../../asset/drone.jpg';
import hidetoheal from '../../../asset/hidetoheal.jpg';
import plugandplay from '../../../asset/plugandplay.jpg';
import digitaltransform from '../../../asset/digitaltransform.jpg';
export interface AcademicEvent {
  id: number;
  title: string;
  speaker: string;
  date: string;
  time: string;
  venue: string;
  dept: 'All' | 'Computer Science' | 'Software Engineering' | 'Cybersecurity' | 'Digital Business' | 'Telecommunication & Networking';
  type: 'Workshop' | 'Conference' | 'Exhibition' | 'Seminar' | 'Networking' | 'Hands-on';
  badge: string;
  image: string;
  description: string;
}

export const FIGMA_EVENTS_DATA: AcademicEvent[] = [
  {
    id: 1,
    title: "Seminar Announcement: From Hide to Heal",
    speaker: "Ms. Sotheary Yim",
    date: "Oct 24, 2024",
    time: "09:00 AM",
    venue: "Innovation Center",
    dept: "Software Engineering",
    type: "Seminar",
    badge: "Seminar",
    image: hidetoheal,
    description: "A deep dive into zero-trust architectures and next-generation threat mitigation strategies."
  },
  {
    id: 2,
    title: "The important of ICT",
    speaker: "Mr. So tominaga",
    date: "Nov 02, 2024",
    time: "10:30 AM",
    venue: "A204,IDT",
    dept: "Computer Science",
    type: "Conference",
    badge: "Conference",
    image: ict,
    description: "Exploring the ethics and implementation of Large Language Models in institutional workflows."
  },
  {
    id: 3,
    title: "Drone contest",
    speaker: "Mariya Garcia",
    date: "Nov 15, 2024",
    time: "02:00 PM",
    venue: "Design Lab 4",
    dept: "Telecommunication & Networking",
    type: "Exhibition",
    badge: "Exhibition",
    image: drone,
    description: "An interactive exhibition featuring the capstone projects of our Digital Media and UX Design students."
  },
  {
    id: 4,
    title: "Plug & Play",
    speaker: "Ms. Leng Pisey",
    date: "Dec 05, 2024",
    time: "10:00 AM",
    venue: "Main Plaza",
    dept: "All",
    type: "Networking",
    badge: "Networking",
    image: plugandplay,
    description: "Connect with over 50 leading technology firms and startups for internship and career opportunities."
  },
  {
    id: 5,
    title: "Digital Transformation",
    speaker: "Prof. Guido Gianasso",
    date: "Dec 12, 2024",
    time: "01:00 PM",
    venue: "Cloud Lab 2",
    dept: "Computer Science",
    type: "Hands-on",
    badge: "Hands-on",
    image: digitaltransform,
    description: "Practical workshop on processing large-scale datasets using AWS and Google Cloud systems."
  },
  {
    id: 6,
    title: "Scholarship to China 2025",
    speaker: "Academic Dean Panel",
    date: "Jan 08, 2025",
    time: "11:00 AM",
    venue: "Boardroom 101",
    dept: "Software Engineering",
    type: "Seminar",
    badge: "Seminar",
    image:scholarship,
    description: "A seminar for aspiring team leads and project managers on navigating shifting digital trends."
  }
];